BẢN CẮT THỬ NGHIỆM / CHƯA DUYỆT
19 file: 8 số/chỉ dẫn đầu (Q1 nằm trong intro), 1 beep, 5 chuyển đoạn Part2, 4 block Q14-15, 1 outro.
Tất cả cắt từ MP3 mẫu. Không thêm nhạc HSK1-6 khi chưa kiểm tra.
Đặc biệt nghe hai file có hậu tố REVIEW: nếu có câu hỏi riêng của đề mẫu thì KHÔNG dùng nguyên file cho đề mới. Xác minh câu hỏi Q14-15 có được đọc hay chỉ hiển thị trên đề giấy.
Thời gian ngoài asset: từ hết câu nghe tới beep ~2.2s; sau beep 10.56-10.60s, Q8 11.09s; Part2 15.09-15.29s; chuẩn bị 180.61-180.66s; trả lời 90.18-90.19s. Đây là khoảng im lặng thực đo -45dB, không phải thời lượng silence cần chèn nguyên xi: trừ padding đầu/cuối.
Giữ nguyên nội dung MP3, không edge-trim asset tự động. Không batch trước golden.
